The AiBridge_ESP32_C3 has been changed to use the ESP32-C3 CPU instead of the ESP32. The CPU core is now RISC-V.

However, the operation methods are compatible with the ESP32. This means that although the CPU differs, the source code and usage are largely the same.




Please rename and upload the JSON file using the file manager. It has been updated to v7.11.

openapi_v7.11.json  ---> openapi.json

alpaca-api-spec_v7.11.json  ---> alpaca-api-spec.json
