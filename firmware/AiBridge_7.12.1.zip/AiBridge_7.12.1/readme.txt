Please rename and upload the JSON file using the file manager. It has been updated to v7.11.

openapi_v7.11.json  ---> openapi.json

alpaca-api-spec_v7.11.json  ---> alpaca-api-spec.json